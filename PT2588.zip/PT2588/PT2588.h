#ifndef PT2588_h
#define PT2588_h

#include <Arduino.h>
#include <Wire.h>

class PT2588{
  public:
  PT2588(boolean a, boolean b);
  byte pt_begin();
  byte clear_resister();
  byte mute(boolean m,byte cha);
  byte setvolume(byte v,byte cha);
  byte setvolume_per(byte v, byte cha);
  private:
  byte _adr;
  byte ch(byte c);
};

#endif